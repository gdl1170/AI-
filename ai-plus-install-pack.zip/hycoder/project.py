"""
AI+ project module: scaffold, test, run, preview.
"""

import os
import sys
import shutil
import subprocess
import tempfile
import json
import time
from pathlib import Path

PROJECTS_DIR = Path.home() / ".config" / "hybrid-coder" / "projects"


def _projects_dir():
    PROJECTS_DIR.mkdir(parents=True, exist_ok=True)
    return PROJECTS_DIR


PYTHON = sys.executable  # python3 on macOS/python on Linux

PROJECT_TEMPLATES = {
    "python": {
        "files": {
            "main.py": 'def main():\n    print("Hello from AI+!")\n\nif __name__ == "__main__":\n    main()\n',
            "tests/test_main.py": 'from main import *\n\ndef test_placeholder():\n    assert True\n',
        },
        "dirs": ["tests"],
        "run": f"{PYTHON} main.py",
        "test": f"{PYTHON} -m pytest tests/ -v",
    },
    "python-flask": {
        "files": {
            "app.py": 'from flask import Flask\n\napp = Flask(__name__)\n\n@app.route("/")\ndef hello():\n    return "Hello from AI+!"\n\nif __name__ == "__main__":\n    app.run(debug=True, port=5000)\n',
            "tests/test_app.py": 'from app import app\n\ndef test_hello():\n    with app.test_client() as c:\n        rv = c.get("/")\n        assert rv.status_code == 200\n',
            "requirements.txt": "flask\npytest\n",
        },
        "dirs": ["tests"],
        "run": f"{PYTHON} app.py",
        "test": f"{PYTHON} -m pytest tests/ -v",
    },
    "html": {
        "files": {
            "index.html": "<!DOCTYPE html>\n<html lang=\"it\">\n<head>\n    <meta charset=\"UTF-8\">\n    <title>Progetto AI+</title>\n    <style>\n        body { font-family: system-ui; max-width: 800px; margin: 40px auto; padding: 0 20px; }\n        h1 { color: #3fb950; }\n    </style>\n</head>\n<body>\n    <h1>Ciao da AI+!</h1>\n    <p>Progetto generato dall\'AI ibrida.</p>\n</body>\n</html>\n",
            "style.css": "body {\n    background: #0d1117;\n    color: #c9d1d9;\n}\n",
        },
        "dirs": [],
        "run": "python -m http.server 8000",
        "test": "",
    },
    "node-js": {
        "files": {
            "index.js": 'console.log("Hello from AI+!");\n\nfunction main() {\n    return "OK";\n}\n\nmodule.exports = { main };\n',
            "tests/test.js": 'const { main } = require("../index");\nconst assert = require("assert");\n\ndescribe("main", () => {\n    it("should return OK", () => {\n        assert.strictEqual(main(), "OK");\n    });\n});\n',
            "package.json": '{\n  "name": "hybrid-project",\n  "version": "1.0.0",\n  "scripts": {\n    "start": "node index.js",\n    "test": "mocha tests/test.js"\n  },\n  "devDependencies": {\n    "mocha": "^10.0.0"\n  }\n}\n',
        },
        "dirs": ["tests"],
        "run": "node index.js",
        "test": "npm test",
    },
}


def list_templates():
    return list(PROJECT_TEMPLATES.keys())


def get_template(name):
    t = PROJECT_TEMPLATES.get(name)
    if not t:
        raise ValueError(f"Template '{name}' non trovato. Disponibili: {', '.join(list_templates())}")
    return t


def create_project(name, template="python", path=None):
    if path is None:
        path = _projects_dir() / name
    else:
        path = Path(path)

    if path.exists():
        raise FileExistsError(f"'{path}' esiste già")

    t = get_template(template)

    path.mkdir(parents=True, exist_ok=True)
    for d in t.get("dirs", []):
        (path / d).mkdir(parents=True, exist_ok=True)

    for filepath, content in t["files"].items():
        fp = path / filepath
        fp.parent.mkdir(parents=True, exist_ok=True)
        fp.write_text(content)

    meta = {
        "name": name,
        "template": template,
        "path": str(path),
        "created": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "run_cmd": t.get("run", ""),
        "test_cmd": t.get("test", ""),
    }
    (path / ".hybrid-project.json").write_text(json.dumps(meta, indent=2))

    return meta


def list_projects():
    d = _projects_dir()
    projects = []
    for p in sorted(d.iterdir()):
        if p.is_dir() and (p / ".hybrid-project.json").exists():
            meta = json.loads((p / ".hybrid-project.json").read_text())
            projects.append(meta)
    return projects


def get_project(name_or_path):
    projects = list_projects()
    for p in projects:
        if p["name"] == name_or_path:
            return p
    p = Path(name_or_path)
    if p.exists() and (p / ".hybrid-project.json").exists():
        return json.loads((p / ".hybrid-project.json").read_text())
    raise FileNotFoundError(f"Progetto '{name_or_path}' non trovato")


def run_project(name_or_path, file=None):
    project = get_project(name_or_path)
    cwd = project["path"]

    if file:
        cmd = [sys.executable, str(Path(cwd) / file)]
    else:
        cmd = project.get("run_cmd", "").split()
        if not cmd:
            raise ValueError(f"Nessun comando di run per '{project['name']}'")

    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=30)
    return {
        "project": project["name"],
        "command": " ".join(cmd),
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
        "success": result.returncode == 0,
    }


def test_project(name_or_path):
    project = get_project(name_or_path)
    cwd = project["path"]
    cmd = project.get("test_cmd", "").split()
    if not cmd:
        return {
            "project": project["name"],
            "command": "",
            "stdout": "",
            "stderr": "Nessun comando di test configurato",
            "returncode": -1,
            "success": False,
        }

    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True, timeout=60)
    return {
        "project": project["name"],
        "command": " ".join(cmd),
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
        "success": result.returncode == 0,
    }


def delete_project(name_or_path):
    project = get_project(name_or_path)
    path = Path(project["path"])
    shutil.rmtree(path)
    return project


def preview_project(name_or_path, file=None):
    project = get_project(name_or_path)
    cwd = Path(project["path"])

    if file:
        files_to_show = [cwd / file]
    else:
        files_to_show = sorted(cwd.rglob("*"))
        files_to_show = [f for f in files_to_show if f.is_file() and f.name != ".hybrid-project.json"]

    sources = {}
    for fp in files_to_show:
        try:
            rel = fp.relative_to(cwd)
            sources[str(rel)] = fp.read_text()
        except Exception:
            pass

    run_result = None
    try:
        run_result = run_project(name_or_path)
    except Exception:
        pass

    return {
        "project": project,
        "sources": sources,
        "output": run_result,
    }


# ── Run arbitrary code (sandboxed for web) ──

# Languages that can be executed
EXECUTABLE_LANGS = {
    ".py": sys.executable,
    ".sh": "/bin/bash",
    ".js": "node",
    ".go": "go run",
}

RUNNABLE_LANG_NAMES = {
    "python": sys.executable,
    "python3": sys.executable,
    "bash": "/bin/bash",
    "sh": "/bin/bash",
    "shell": "/bin/bash",
    "javascript": "node",
    "js": "node",
    "typescript": "npx tsx",
    "ts": "npx tsx",
    "ruby": "ruby",
    "php": "php",
    "go": "go run",
}

def _cmd_for(language, fpath, code):
    interp = RUNNABLE_LANG_NAMES.get(language)
    if interp == "go run":
        fpath.write_text(f"package main\n\nimport \"fmt\"\n\nfunc main() {{\n{code}\n}}")
        return ["go", "run", str(fpath)]
    if interp == "npx tsx":
        return ["npx", "tsx", str(fpath)]
    return [interp, str(fpath)]


def run_code(code, language="python"):
    interpreter = RUNNABLE_LANG_NAMES.get(language)
    if not interpreter:
        return {
            "success": False,
            "stdout": "",
            "stderr": f"Linguaggio '{language}' non supportato. Supportati: {', '.join(RUNNABLE_LANG_NAMES.keys())}",
            "returncode": -1,
        }

    import time as _time
    t0 = _time.time()
    with tempfile.TemporaryDirectory() as tmpdir:
        ext = ".py" if language in ("python", "python3") else ".sh" if language in ("bash", "sh", "shell") else ".js" if language in ("javascript", "js") else ".ts" if language in ("typescript", "ts") else ".rb" if language == "ruby" else ".php" if language == "php" else ".txt"
        fpath = Path(tmpdir) / f"code{ext}"
        fpath.write_text(code)
        os.chmod(fpath, 0o755)

        cmd = _cmd_for(language, fpath, code)

        try:
            result = subprocess.run(cmd, cwd=tmpdir, capture_output=True, text=True, timeout=30)
            elapsed = int((_time.time() - t0) * 1000)
            return {
                "success": result.returncode == 0,
                "stdout": result.stdout,
                "stderr": result.stderr,
                "returncode": result.returncode,
                "time_ms": elapsed,
            }
        except subprocess.TimeoutExpired:
            elapsed = int((_time.time() - t0) * 1000)
            return {
                "success": False,
                "stdout": "",
                "stderr": "Timeout (30s)",
                "returncode": -1,
                "time_ms": elapsed,
            }
        except FileNotFoundError as e:
            elapsed = int((_time.time() - t0) * 1000)
            return {
                "success": False,
                "stdout": "",
                "stderr": f"Interprete non trovato: {e}",
                "returncode": -1,
                "time_ms": elapsed,
            }
